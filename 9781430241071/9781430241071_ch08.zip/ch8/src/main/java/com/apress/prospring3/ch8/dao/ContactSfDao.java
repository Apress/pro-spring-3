/**
 * Created on Nov 16, 2011
 */
package com.apress.prospring3.ch8.dao;

/**
 * @author Clarence
 *
 */
public interface ContactSfDao {

	public String getFirstNameById(Long id);
	
}
