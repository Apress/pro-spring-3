/*
 * Created on Oct 8, 2011
 */
package com.apress.prospring3.ch7.pfb;

/**
 * @author clarence
 */
public class MyDependency {

    public void foo() {
        System.out.println("foo()");
    }
    
    public void bar() {
        System.out.println("bar()");
    }
}
