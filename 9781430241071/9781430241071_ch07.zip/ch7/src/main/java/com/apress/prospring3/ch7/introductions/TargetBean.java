/*
 * Created on Oct 7, 2011
 */
package com.apress.prospring3.ch7.introductions;

/**
 * @author clarence
 */
public class TargetBean {

    private String name;
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getName() {
        return name;
    }
}
