/*
 * Created on Oct 2, 201
 */
package com.apress.prospring3.ch7.composable;

/**
 * @author clarence
 */
public class SampleBean {

    public String getName() {
        return "Clarence Ho";
    }
    
    public void setName(String name) { 
    }
    
    public int getAge() {
        return 100;
    }
}
