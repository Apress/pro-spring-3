/*
 * Created on Oct 2, 2011
 */
package com.apress.prospring3.ch7.introductions;

/**
 * @author clarence
 */
public interface IsModified {

    public boolean isModified();
}
