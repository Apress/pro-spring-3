/*
 * Created on Oct 2, 2011
 */
package com.apress.prospring3.ch7.cflow;

/**
 * @author clarence
 */
public class TestBean {

    public void foo() {
        System.out.println("foo()");
    }
}
