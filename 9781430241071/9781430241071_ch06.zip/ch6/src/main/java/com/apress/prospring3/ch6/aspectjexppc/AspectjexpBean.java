/*
 * Created on Sep 30, 2011
 */
package com.apress.prospring3.ch6.aspectjexppc;

/**
 * @author clarence
 */
public class AspectjexpBean {

    public void foo1() {
        System.out.println("foo1");
    }
    
    public void foo2() {
        System.out.println("foo2");
    }
    
    public void bar() {
        System.out.println("bar");
    }
}
