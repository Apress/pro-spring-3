/*
 * Created on Sep 30, 2011
 */
package com.apress.prospring3.ch6.proxies;

/**
 * @author clarence
 */
public interface ISimpleBean {

    public void advised();
    public void unadvised();
    
}
