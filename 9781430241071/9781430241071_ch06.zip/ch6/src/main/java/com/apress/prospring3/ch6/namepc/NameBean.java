/*
 * Created on Sep 30, 2011
 */
package com.apress.prospring3.ch6.namepc;

/**
 * @author clarence
 */
public class NameBean {

    public void foo() {
        System.out.println("foo");
    }
    
    public void foo(int x) {
        System.out.println("foo " + x);
    }
    
    public void bar() {
        System.out.println("bar");
    }
    
    public void yup() {
        System.out.println("yup");
    }
}
