/*
 * Created on Sep 30, 2011
 */
package com.apress.prospring3.ch6.staticpc;

/**
 * @author clarence
 */
public class BeanOne {

    public void foo() {
        System.out.println("foo");
    }
    
    public void bar() {
        System.out.println("bar");
    }
}
