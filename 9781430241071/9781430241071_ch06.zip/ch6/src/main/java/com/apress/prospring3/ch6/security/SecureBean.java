/*
 * Created on Sep 30, 2011
 */
package com.apress.prospring3.ch6.security;

/**
 * @author clarence
 */
public class SecureBean {

    public void writeSecureMessage() {
        System.out.println("Every time I learn something new, "
                + "it pushes some old stuff out my brain");
    }
}