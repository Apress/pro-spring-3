/*
 * Created on Sep 30, 2011
 */
package com.apress.prospring3.ch6;

/**
 * @author clarence
 */
public class MessageWriter {

    public void writeMessage() {
        System.out.print("World");
    }

}