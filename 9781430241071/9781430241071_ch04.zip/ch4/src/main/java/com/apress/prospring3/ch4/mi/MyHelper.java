/**
 * Created on Sep 23, 2011
 */
package com.apress.prospring3.ch4.mi;

/**
 * @author Clarence
 *
 */
public class MyHelper {

	public void doSomethingHelpful() {
		// do something! 
	}
	
}
