/**
 * Created on Sep 21, 2011
 */
package com.apress.prospring3.ch4;

/**
 * @author Clarence
 *
 */
public class SimpleTarget {

    private String val;
    
    public void setVal(String val) {
        this.val = val;
    }
    
    public String getVal() {
        return val;
    }
	
}
