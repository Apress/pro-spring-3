/**
 * Created on Sep 23, 2011
 */
package com.apress.prospring3.ch4.mi;

/**
 * @author Clarence
 *
 */
public interface DemoBean {

	public MyHelper getMyHelper(); 
	
	public void someOperation();
	
}
