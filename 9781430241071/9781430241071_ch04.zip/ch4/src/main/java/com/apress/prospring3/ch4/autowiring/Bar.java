/*
 * Created on Sep 22, 2011
 */
package com.apress.prospring3.ch4.autowiring;

/**
 * @author clarence
 */
public class Bar {

}
