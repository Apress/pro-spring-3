/**
 * Created on Dec 15, 2011
 */
package com.apress.prospring3.springblog.service;

import com.apress.prospring3.springblog.domain.EntryAttachment;

/**
 * @author Clarence
 *
 */
public interface EntryAttachmentService {

	public EntryAttachment findById(Long id);
	
}
