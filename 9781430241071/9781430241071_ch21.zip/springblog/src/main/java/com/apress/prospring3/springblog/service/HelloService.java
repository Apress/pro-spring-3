/**
 * Created on Oct 21, 2011
 */
package com.apress.prospring3.springblog.service;

/**
 * @author Clarence
 *
 */
public interface HelloService {

	public String sayHello();	
	
}
