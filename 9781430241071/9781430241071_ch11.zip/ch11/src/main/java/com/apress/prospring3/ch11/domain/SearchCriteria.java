/**
 * Created on Oct 24, 2011
 */
package com.apress.prospring3.ch11.domain;

/**
 * @author Clarence
 *
 */
public class SearchCriteria {

	private String firstName;
	private String lastName;
	
	public String getFirstName() {
		return firstName;
	}
	
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}	
	
}
