/**
 * Created on Nov 2, 2011
 */
package com.apress.prospring3.ch12.service.impl;

import com.apress.prospring3.ch12.service.OrderService;

/**
 * @author Clarence
 *
 */
public class SuperOrderServiceImpl implements OrderService {

}
