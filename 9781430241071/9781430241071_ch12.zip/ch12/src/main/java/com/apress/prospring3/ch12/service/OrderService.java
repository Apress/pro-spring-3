/**
 * Created on Nov 2, 2011
 */
package com.apress.prospring3.ch12.service;

/**
 * @author Clarence
 *
 */
public interface OrderService {

}
