/**
 * Created on Sep 26, 2011
 */
package com.apress.prospring3.ch5.profile;

import java.util.List;

/**
 * @author Clarence
 *
 */
public interface FoodProviderService {

	public List<Food> provideLunchSet();
	
}
