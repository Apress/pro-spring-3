/**
 * Created on Sep 26, 2011
 */
package com.apress.prospring3.ch5.javaconfig;

import org.springframework.context.annotation.Configuration;

/**
 * @author Clarence
 *
 */
@Configuration
public class OtherConfig {

}
