/**
 * Created on Sep 11, 2011
 */
package com.apress.prospring3.ch5.javaconfig;

/**
 * @author Clarence
 *
 */
public interface MessageProvider {

	public String getMessage();
	
}
