/**
 * Created on Sep 26, 2011
 */
package com.apress.prospring3.ch5.env;

/**
 * @author Clarence
 *
 */
public class AppProperty {

	private String applicationHome;

	private String userHome;

	public String getApplicationHome() {
		return applicationHome;
	}

	public void setApplicationHome(String applicationHome) {
		this.applicationHome = applicationHome;
	}

	public String getUserHome() {
		return userHome;
	}

	public void setUserHome(String userHome) {
		this.userHome = userHome;
	}	
	
}
