/**
 * Created on Sep 11, 2011
 */
package com.apress.prospring3.ch5.jsr330;

/**
 * @author Clarence
 *
 */
public interface MessageProvider {

	public String getMessage();
	
}
