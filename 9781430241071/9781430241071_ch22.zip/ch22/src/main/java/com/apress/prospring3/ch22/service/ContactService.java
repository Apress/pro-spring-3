/**
 * Created on Jan 16, 2012
 */
package com.apress.prospring3.ch22.service;

import com.apress.prospring3.ch22.domain.Contact;

/**
 * @author Clarence
 *
 */
public interface ContactService {

	public void applyRule(Contact contact);
	
}
