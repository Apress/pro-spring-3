/**
 * Created on Jan 16, 2012
 */
package com.apress.prospring3.ch22.groovy.closure

def names = ['Clarence', 'Johnny', 'Mary']

names.each {println 'Hello: ' + it}