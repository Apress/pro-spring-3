/**
 * Created on Jan 16, 2012
 */
package com.apress.prospring3.ch22.rule.domain

/**
 * @author Clarence
 *
 */
class Rule {

	private boolean singlehit = true
	private conditions = new ArrayList()
	private actions = new ArrayList()
	private parameters = new ArrayList()
	
}
