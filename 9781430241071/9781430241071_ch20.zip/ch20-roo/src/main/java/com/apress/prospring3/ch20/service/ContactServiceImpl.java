package com.apress.prospring3.ch20.service;


public class ContactServiceImpl implements ContactService {
}
