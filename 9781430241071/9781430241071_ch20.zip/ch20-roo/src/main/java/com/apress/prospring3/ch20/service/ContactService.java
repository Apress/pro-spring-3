package com.apress.prospring3.ch20.service;

import org.springframework.roo.addon.layers.service.RooService;

@RooService(domainTypes = { com.apress.prospring3.ch20.domain.Contact.class })
public interface ContactService {
}
