/**
 * Created on Sep 11, 2011
 */
package com.apress.prospring3.ch2;

/**
 * @author Clarence
 *
 */
public class HelloWorld {

	public static void main(String[] args) {

		System.out.println("Hello World!");

	}

}
