/**
 * Created on Nov 30, 2011
 */
package com.apress.prospring3.ch16.jms.sender;

/**
 * @author Clarence
 *
 */
public interface MessageSender {

	public void sendMessage(String message);
	
}
